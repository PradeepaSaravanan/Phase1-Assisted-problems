package accessspecifiers;

public class Protectedaccess {
protected  int addition( int n, int m)
{
	 int res;
	 res= n+m;
	 return res;
}
}
