package accessspecifiers;
import accessspecifiers.Publicaccess;
public class Accesspublic extends Publicaccess {

	public static void main(String[] args) {
		
		Accesspublic obj= new Accesspublic();
		obj.display();
	}

}
