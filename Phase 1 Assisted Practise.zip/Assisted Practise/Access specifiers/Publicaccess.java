package accessspecifiers;

public class Publicaccess {
 public void display()
 {
	 System.out.println("Public methods is created");
 }
}
